<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
$level = $_SESSION['level']; 
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - English Master</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
       body {
            font-family: 'Poppins', sans-serif;
            /* Bulanık, sakin bir kahve/kitap ortamı */
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), 
                        url('https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=1920&auto=format&fit=crop');
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            background-size: cover;
            height: 100vh;
            color: white;
        }

        /* Arka planı karartan katman */
        .overlay {
            background-color: rgba(0, 0, 0, 0.7); /* %70 Siyahlık */
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        /* İçeriğin üstte kalması için */
        .content-wrapper {
            position: relative;
            z-index: 2;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Navbar Özelleştirme */
        .navbar {
            background-color: rgba(0, 0, 0, 0.5) !important; /* Yarı saydam menü */
            backdrop-filter: blur(10px); /* Modern buzlu cam efekti */
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .nav-link {
            color: rgba(255,255,255,0.8) !important;
            font-weight: 500;
            margin-right: 15px;
            transition: color 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            color: #fff !important;
            border-bottom: 2px solid #0d6efd; /* Hover olunca alt çizgi */
        }
        
        /* Ortadaki Karşılama Alanı */
        .hero-section {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
        }
        .level-badge {
            background-color: #ffc107;
            color: #000;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9rem;
            text-transform: uppercase;
        }
    </style>
</head>
<body>

<div class="overlay"></div>

<div class="content-wrapper">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">🎓 English Master</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="grammar.php">Grammar</a></li>
                    <li class="nav-item"><a class="nav-link" href="vocab.php">Vocabulary</a></li>
                    <li class="nav-item"><a class="nav-link" href="reading.php">Reading</a></li>
                    <li class="nav-item"><a class="nav-link text-warning" href="ai_practice.php">🤖 AI Practice</a></li>
                </ul>
                
                <div class="d-flex align-items-center text-white">
                    <div class="text-end me-3">
                        <div class="fw-bold"><?php echo htmlspecialchars($username); ?></div>
                        <div class="badge bg-primary">Seviye: <?php echo $level; ?></div>
                    </div>
                    <a href="logout.php" class="btn btn-outline-danger btn-sm">Çıkış</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container hero-section">
        <div>
            <span class="level-badge mb-3 d-inline-block">Student Dashboard</span>
            <h1 class="display-3 fw-bold mb-3">Welcome Back, <?php echo htmlspecialchars($username); ?>!</h1>
            <p class="lead mb-4 text-white-50">Kaldığın yerden devam etmeye hazır mısın?<br>Bugünkü hedefin: AI ile 5 dakika sohbet etmek.</p>
            
            <div class="d-flex justify-content-center gap-3">
                <a href="ai_practice.php" class="btn btn-primary btn-lg px-5 shadow-lg">🤖 AI ile Konuş</a>
                <a href="vocab.php" class="btn btn-outline-light btn-lg px-5">Kelime Çalış</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>